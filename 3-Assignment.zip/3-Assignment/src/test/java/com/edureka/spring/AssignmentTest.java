package com.edureka.spring;

import java.util.Arrays;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.edureka.spring.assignment.EmployeeRepository;
import com.edureka.spring.assignment.Employee;

@SpringBootTest
public class AssignmentTest {
	
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	@Test
	public void shouldInsertEmployee() {
		Employee firstemployee = Employee.builder()
				.id(1)
				.firstName("John")
				.lastName("Lee")
				.build();
		employeeRepository.save(firstemployee);
		
		Optional<Employee> firstEmployee1 = employeeRepository.findById(1);
		Assertions.assertThat(firstEmployee1.isPresent()).isTrue();
		Assertions.assertThat(firstEmployee1.get()).isEqualTo(firstemployee);
	}	

}
